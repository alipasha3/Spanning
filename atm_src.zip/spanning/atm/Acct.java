package atm;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;

/*
 * The Acct class creates a bank account, and is intended 
 * to be used with the ATM classe.
 * 
 * The Acct class does NOT ensure that account numbers 
 * are unique.
 */

public class Acct {
	
	private int acctNum;       			//account or card number
	private String acctName;   			//account holder's name
	private int acctPin;       			//account password
	private double balance;       		//current balance in account
	private ArrayList<String> history;  //transaction history

    public Acct()
    {
        acctNum = new java.util.Random().nextInt(9000) + 1000;
        acctName = "This account is invalid";
        acctPin = 0000;
        balance = 0;
    
        history = new ArrayList<String>();
    		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
        history.add(dateFormat.format(Calendar.getInstance().getTime()) + 
        		"\n  Account created" +
        		"\n    Initial Balance: $0.00");
    }
    
    public Acct(String name, int pin, double initialBalance) 
    {
    		acctNum = new java.util.Random().nextInt(9000) + 1000;
    		acctName = name;
    		acctPin = pin;
    		balance = initialBalance;
    	
    		history = new ArrayList<String>();
    		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
        history.add(dateFormat.format(Calendar.getInstance().getTime()) + 
        		"\n  Account created" +
        		"\n    Initial Balance: $" + Double.toString(initialBalance));
    }
    
    public Acct(int num, String name, int pin, double initialBalance) 
    {
	    	acctNum = num;
	    	acctName = name;
	    	acctPin = pin;
	    	balance = initialBalance;
	    	
	    	history = new ArrayList<String>();
	    	DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
	    	history.add(dateFormat.format(Calendar.getInstance().getTime()) + 
	        		"\n  Account created" +
	        		"\n    Initial Balance: $" + Double.toString(initialBalance));
    }
    
    public int getAcctNum() { return this.acctNum; }
    
    public String getAcctName() { return this.acctName; }
    
    public int getAcctPin() { return this.acctPin; }
    
    public double getBalance() { return this.balance; }
    
    public ArrayList<String> getHistory() { return this.history; }
    
    public void setAcctName(String name) { this.acctName = name; }
    
    public void setAcctPin(int pin) { this.acctPin = pin; }
    
    public void incrBalance(double amt2Add) 
    {
    	DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
    	this.history.add(dateFormat.format(Calendar.getInstance().getTime()) + 
    			"\n  Deposit: $" + Double.toString(amt2Add) +
    			"\n    Old Balance: $" + Double.toString(this.balance) + 
    			"\n    New Balance: $" + Double.toString(this.balance += amt2Add));
    }
    
    public void decrBalance(double amt2Sub) 
    {
    	DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
    	this.history.add(dateFormat.format(Calendar.getInstance().getTime()) +
    			"\n  Withdrawal: $" + Double.toString(amt2Sub) +
    			"\n    Old Balance: $" + Double.toString(this.balance) + 
    			"\n    New Balance: $" + Double.toString(this.balance -= amt2Sub));
    }
}
