package atm;

import java.util.HashMap;
import atm.ATM;
import atm.Acct;

public class Main {

	public static void main(String[] args) {
		
		HashMap<Integer, Acct> accounts = new HashMap<Integer, Acct>();
		
		Acct acct = new Acct(1111, "Ronald", 3942, 9999999.99);
		accounts.put(acct.getAcctNum(), acct);
		
		acct = new Acct(2222, "Hamburgler", 9347, 1923857.54);
		accounts.put(acct.getAcctNum(), acct);
		
		acct = new Acct(3333, "Purple Thing", 8462, 0.54);
		accounts.put(acct.getAcctNum(), acct);
		
		acct = new Acct(5862, "Worker", 9405, 467.54);
		accounts.put(acct.getAcctNum(), acct);
		
		ATM atm = new ATM(accounts);
		atm.startATM();
	}

}
