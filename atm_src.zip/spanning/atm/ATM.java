package atm;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;


/*
 * The ATM class expects a HashMap where the key is an 
 * Integer account number and the value is an Acct class account.
 * 
 * Assumptions: 
 * -ATM has only numeric keys so user can only enter positive 
 *      integers or doubles for deposit and withdrawals     
 * -All account numbers are unique
 * -All accounts are Acct objects
 */
public class ATM 
{
	
	private HashMap<Integer, Acct> accounts;
	private Acct currentAcct;
	
	public ATM() 
	{	
		accounts = new HashMap<Integer, Acct>(); 
		currentAcct = null;
	}
	
	public ATM(HashMap<Integer, Acct> accts) 
	{ 
		accounts = accts;
		currentAcct = null;
	}
	
	/*
	 * startATM() method starts the ATM machines
	 * and runs in an infinite loop until the user
	 * requests it to be shutdown
	 */
	public void startATM() 
	{
		boolean userCleared = false, logout = false;
		Scanner scanner = new Scanner(System.in);
		while (true) //loop until user requests to shutdown ATM
		{
			while (!userCleared) //loop until a user has passed security clearance
			{
				displayMainMenu();
				int accountNum = getUserIntInput(scanner);
				if (accountNum == 0) 
				{
					scanner.close();
					System.exit(0); 
				}
				userCleared = isUserCleared(accountNum, this.accounts, scanner);
				if (userCleared) { currentAcct = getAccount(accountNum, this.accounts); }
				else { displayInvalidCredentials(); }
			}
			if (currentAcct == null) //just check in case something bad slipped through
			{ 
				System.out.println("System error");
				scanner.close();
				System.exit(0);
			}
			
			//make userCleared equal false so that the main menu 
			//runs again upon the current user's logout
			userCleared = false;
			
			//loop until user requests to logout
			while (!logout) 
			{
				displayUserMenu(currentAcct);
				logout = executeUserMenuInput(currentAcct, scanner);
			}
			//make logout equal false so that the next user is able to 
			//login
			logout = false;
		}//end of while loop to check if user is cleared
	}
	
	public static void displayMainMenu() 
	{
		System.out.println("\n");
		System.out.println("_____________________________________\n" +
                           "|                                    |\n" +
                           "|                                    |\n" +
                           "| Automated Teller Machine           |\n" +
                           "|                                    |\n" +
                           "| Please enter your card number:     |\n" +
                           "|                                    |\n" +
                           "|____________________________________|\n" +
                           "| press 0 to shutdown                |\n" +
                           "|____________________________________|" );
	}
	
	public static void displayPinMenu() 
	{
		System.out.println("\n");
		System.out.println("______________________________________\n" +
				          "|                                     |\n" +
				          "|                                     |\n" +
				          "| Automated Teller Machine            |\n" +
				          "|                                     |\n" +
				          "| Please enter your card's pin:       |\n" +
				          "|                                     |\n" +
				          "|____________________________________ |");
	}
	
	public static void displayUserMenu(Acct acct) 
	{
		System.out.println("\n");
		System.out.println("_____________________________________\n" +
				          "|                                    |\n" +
				          "|                                    |\n" +
				          "| Automated Teller Machine           |\n" +
				          "|                                    |\n" +
				          "| Welcome " + acct.getAcctName()+"!   \n" +
				          "|                                    |\n" +
				          "|_________________________________   |\n" +
				          "| press 1 to make a deposit          |\n" +
				          "| press 2 to make a withdrawal       |\n" +
				          "| press 3 to view current balance    |\n" +
				          "| press 4 to view transaction history|\n" +
				          "| press 5 to log out                 |\n" +
				  		  "|____________________________________|" );		
	}
	
	public static void displayMoreTransactionsMenu() 
	{
		System.out.println("\n");
		System.out.println("_____________________________________\n" +
						  "|                                    |\n" +
						  "|                                    |\n" +
						  "| Do you wish to make anymore        |\n" +
						  "| transactions?                      |\n" +
						  "|                                    |\n" +
						  "|____________________________________|\n" +
						  "|                                    |\n" +
				  	  	  "| Enter 1 to make another transaction|\n" +
				  	  	  "| Enter 2 to log out                 |\n" +
				  		  "|____________________________________|" );
	}
	
	public static void displayDepositMenu() 
	{
		System.out.println("\n");
		System.out.println("_____________________________________\n" +
						  "|                                    |\n" +
						  "|                                    |\n" +
						  "| Please enter the amount you        |\n" +
						  "| are depositing                     |\n" +
						  "|                                    |\n" +
						  "|____________________________________|\n" +
						  "|                                    |\n" +
				  	  	  "| Enter 0 to cancel this transaction |\n" +
				  		  "|____________________________________|" );
	}
	
	public static void displayWithdrawalMenu() 
	{
		System.out.println("\n");
		System.out.println("_____________________________________\n" +
						  "|                                    |\n" +
						  "|                                    |\n" +
						  "| Please enter the amount you        |\n" +
						  "| are withdrawing                    |\n" +
						  "|                                    |\n" +
						  "|____________________________________|\n" +
						  "|                                    |\n" +
				  	  	  "| Enter 0 to cancel this transaction |\n" +
				  		  "|____________________________________|" );
	}
	
	public static void displayInvalidCredentials() 
	{
		System.out.println("\n");
		System.out.println("_____________________________________\n" +
                           "|                                    |\n" +
                           "|                                    |\n" +
                           "| Invalid credentials                |\n" +
                           "|                                    |\n" +
                           "|____________________________________|" );
	}
	
	public static void displayInvalidSelection() 
	{
		System.out.println("\n");
		System.out.println("_____________________________________\n" +
                           "|                                    |\n" +
                           "|                                    |\n" +
                           "| Invalid selection                  |\n" +
                           "|                                    |\n" +
                           "|____________________________________|" );
	}
	
	public static void displayInvalidEntry() 
	{
		System.out.println("\n");
		System.out.println("_____________________________________\n" +
                           "|                                    |\n" +
                           "|                                    |\n" +
                           "| Invalid Entry                      |\n" +
                           "|                                    |\n" +
                           "|____________________________________|" );
	}
	
	public static void displayBalance(Acct acct) 
	{
		System.out.println("_____________________________________\n" +
                           "|                                    |\n" +
                           "|                                    |\n" +
                           "| Your current balance is:           |\n" +
                           "|                                    |\n" +
                           "|____________________________________|\n" +
                           "|                                    |\n" +
                           "| $" + getBalance(acct) +            "\n" +
                           "|____________________________________|" );
	}
	
	public static void displayTransactionComplete() 
	{
		System.out.println("_____________________________________\n" +
                           "|                                    |\n" +
                           "|                                    |\n" +
                           "| Transaction complete               |\n" +
                           "|                                    |\n" +
                           "|____________________________________|" );
	}
	
	public static void displayAmount2Large() 
	{
		System.out.println("_____________________________________\n" +
                           "|                                    |\n" +
                           "|                                    |\n" +
                           "| Amount too large. Please see a     |\n" +
                           "| teller, or decrease the deposit    |\n" +
                           "| amount.                            |\n" +
                           "|                                    |\n" +
                           "|____________________________________|" );
	}
	
	public static void displayTransactionTerminated() 
	{
		System.out.println("_____________________________________\n" +
                           "|                                    |\n" +
                           "|                                    |\n" +
                           "| Current transaction terminated     |\n" +
                           "|                                    |\n" +
                           "|____________________________________|" );
	}
	
	public static void displayHistory(Acct acct) 
	{
		System.out.println("_____________________________________\n" +
                           "|                                    |\n" +
                           "|                                    |\n" +
                           "| Your transaction history           |\n" +
                           "|                                    |\n" +
                           "|____________________________________|\n" +
                           "|                                    |" );
		ArrayList<String> history = getHistory(acct);
		for (int i = history.size() - 1; i >= 0; i--) 
		{
			System.out.println("");
			System.out.println(history.get(i));
		}
		System.out.println("|___________________________________|");
	}
	
	public static Acct getAccount(int acctNum, HashMap<Integer, Acct> accounts) 
	{
		return accounts.get(acctNum);
	}
	
	public static double getBalance(Acct acct)
	{
		return acct.getBalance();
	}
	
	public static ArrayList<String> getHistory(Acct acct) 
	{
		return acct.getHistory();
	}
	
	public static double getUserDoubleInput(Scanner scanner) 
	{
		//originally had scanner open and close in here but 
		//it wouldn't work
		System.out.print(">>");
		return Double.parseDouble(scanner.next());
	}
	
	public static int getUserIntInput(Scanner scanner)
	{
		//originally had scanner open and close in here but 
		//it wouldn't work
		System.out.print(">>");	
		String input = scanner.next();
		if (input.contains(".")) { return -1; }
		else { return Integer.parseInt(input); }
	}
	
	public static void makeDeposit(Acct acct, double amt2Deposit) 
	{
		if (amt2Deposit > Double.MAX_VALUE) 
		{
			displayAmount2Large();
			displayTransactionTerminated();
		}
		else if (amt2Deposit < 0) 
		{
			displayInvalidEntry();
			displayTransactionTerminated();
		}
		else if(amt2Deposit == 0)
		{
			//user has decided to cancel this transaction so do nothing
		}
		else 
		{
			acct.incrBalance(amt2Deposit);
			displayTransactionComplete();
		}
	}
	
	public static void makeWithdrawal(Acct acct, double amt2Withdraw) 
	{
		if (amt2Withdraw > Double.MAX_VALUE) 
		{
			displayAmount2Large();
			displayTransactionTerminated();
		}
		else if (amt2Withdraw < 0) 
		{
			displayInvalidEntry();
			displayTransactionTerminated();
		}
		else if (amt2Withdraw == 0)
		{
			//user has decided to cancel transaction so do nothing
		}
		else
		{
			acct.decrBalance(amt2Withdraw);
			displayTransactionComplete();
		}
	}
	
	public static boolean doesUserWant2Logout(Scanner scanner) 
	{
		int attempts = 3;
		displayMoreTransactionsMenu();
		double selection = getUserDoubleInput(scanner);
		while (selection != 1 && selection != 2) 
		{
			if (attempts-- == 0) { return true; }
			displayInvalidEntry();
			displayMoreTransactionsMenu();
			selection = getUserDoubleInput(scanner); 
		}
		if (selection == 2) { return true; }
		return false;
	}
	
	public static boolean accountMatchesPin(Acct account, int accountPin) 
	{
		if (account == null) { return false; }
		if (account.getAcctPin() == accountPin) { return true; }
		return false;
	}
	
	public static boolean isUserCleared(int acctNum, HashMap<Integer, 
			Acct> accounts, Scanner scanner) 
	{
		displayPinMenu();
		int accountPin = getUserIntInput(scanner);
		if (accountMatchesPin(getAccount(acctNum, accounts), accountPin)) { return true; } 
		else { return false; }
	}
	
	public static boolean executeUserMenuInput(Acct currentAcct, Scanner scanner) 
	{
		switch (getUserIntInput(scanner)) 
		{
			case 1: displayDepositMenu();
					makeDeposit(currentAcct, getUserDoubleInput(scanner));
					return doesUserWant2Logout(scanner);
			case 2: displayWithdrawalMenu();
					makeWithdrawal(currentAcct, getUserDoubleInput(scanner));
					return doesUserWant2Logout(scanner);
			case 3: displayBalance(currentAcct);
					return doesUserWant2Logout(scanner);
			case 4: displayHistory(currentAcct);
					return doesUserWant2Logout(scanner);
			case 5: return true;
			default: displayInvalidSelection();
					return false;
		}
	}
}