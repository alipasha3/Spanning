package atmUnitTests;

import static org.junit.Assert.*;
import java.util.HashMap;
import org.junit.Test;
import atm.Acct;
import atm.ATM;

public class GetAccountTest {

	/*
	 * Test if the Acct object returned by ATM.getAccount 
	 * points to the same Acct object as was originally 
	 * added to the accounts HashMap
	 */
	@Test
	public void getAccountTest() 
	{
		HashMap<Integer, Acct> accounts = new HashMap<Integer, Acct>();
		Acct acct = new Acct(1111, "Ronald", 3942, 0);
		accounts.put(acct.getAcctNum(), acct);
		assertSame(acct, ATM.getAccount(1111, accounts));
	}

}
