package atmUnitTests;

import static org.junit.Assert.*;
import java.util.HashMap;
import org.junit.Test;

import atm.ATM;
import atm.Acct;

public class GetBalanceTest {

	@Test
	public void getBalanceTest() 
	{
		Acct acct = new Acct(1111, "Ronald", 3942, 0);
		assertEquals(acct.getBalance(), ATM.getBalance(acct), 0.0);
	}

}
