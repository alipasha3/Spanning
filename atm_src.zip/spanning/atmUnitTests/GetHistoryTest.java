package atmUnitTests;

import static org.junit.Assert.*;
import java.util.HashMap;
import org.junit.Test;
import atm.ATM;
import atm.Acct;

public class GetHistoryTest {

	@Test
	public void getHistoryTest() 
	{
		HashMap<Integer, Acct> accounts = new HashMap<Integer, Acct>();
		Acct acct = new Acct(1111, "Ronald", 3942, 0);
		accounts.put(acct.getAcctNum(), acct);
		assertSame(acct.getHistory(), ATM.getHistory(acct));
	}

}
