package atmUnitTests;

import static org.junit.Assert.*;
import java.util.HashMap;
import org.junit.Test;

import atm.ATM;
import atm.Acct;

public class MakeDepositTest {

	@Test
	public void makeDepositTest1() 
	{
		HashMap<Integer, Acct> accounts = new HashMap<Integer, Acct>();
		Acct acct = new Acct(1111, "Ronald", 3942, 0);
		accounts.put(acct.getAcctNum(), acct);
		ATM.makeDeposit(acct, 100);
		assertEquals(100, acct.getBalance(), 0.0);
	}
	
	@Test
	public void makeDepositTest2() 
	{
		HashMap<Integer, Acct> accounts = new HashMap<Integer, Acct>();
		Acct acct = new Acct(1111, "Ronald", 3942, 99999.99);
		accounts.put(acct.getAcctNum(), acct);
		ATM.makeDeposit(acct, 0.01);
		assertEquals(100000, acct.getBalance(), 0.0);
	}

	@Test
	public void makeDepositTest3() 
	{
		HashMap<Integer, Acct> accounts = new HashMap<Integer, Acct>();
		Acct acct = new Acct(1111, "Ronald", 3942, -200);
		accounts.put(acct.getAcctNum(), acct);
		ATM.makeDeposit(acct, 100);
		assertEquals(-100, acct.getBalance(), 0.0);
	}
}
