package atmUnitTests;

import static org.junit.Assert.*;
import java.util.HashMap;
import org.junit.Test;

import atm.ATM;
import atm.Acct;

public class MakeWithdrawalTest {

	@Test
	public void makeWithdrawalTest() {
		HashMap<Integer, Acct> accounts = new HashMap<Integer, Acct>();
		Acct acct = new Acct(1111, "Ronald", 3942, 200);
		accounts.put(acct.getAcctNum(), acct);
		ATM.makeWithdrawal(acct, 100);
		assertEquals(100, acct.getBalance(), 0.0);
	}
	@Test
	public void makeWithdrawalTest2() {
		HashMap<Integer, Acct> accounts = new HashMap<Integer, Acct>();
		Acct acct = new Acct(1111, "Ronald", 3942, 0);
		accounts.put(acct.getAcctNum(), acct);
		ATM.makeWithdrawal(acct, 100);
		assertEquals(-100, acct.getBalance(), 0.0);
	}
	
	@Test
	public void makeWithdrawalTest3() {
		HashMap<Integer, Acct> accounts = new HashMap<Integer, Acct>();
		Acct acct = new Acct(1111, "Ronald", 3942, -100);
		accounts.put(acct.getAcctNum(), acct);
		ATM.makeWithdrawal(acct, 100);
		assertEquals(-200, acct.getBalance(), 0.0);
	}
}
