package atmUnitTests;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ GetAccountTest.class, GetBalanceTest.class, GetHistoryTest.class, MakeDepositTest.class,
		MakeWithdrawalTest.class })
public class AllATMTests {

}
